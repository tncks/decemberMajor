#include "bpt.h"

#ifndef SIZE_INT64
#define SIZE_INT64 sizeof(int64_t)
#endif
#ifndef SIZE_OFFSET
#define SIZE_OFFSET sizeof(off_t)
#endif
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif
#ifndef FIX_SIZE
#define FIX_SIZE 120
#endif
#define INSERT 'i'
#define FIND 'f'
#define DELETE 'd'
#define QUIT 'q'
#define JOIN 'j'



int main(){
    int64_t key_input;
    char user_interaction_input;
    char user_value_input[FIX_SIZE];
    char *result_value_string;
    setvbuf(stdout, NULL, _IONBF, 0);

    /*****************************/



    preprocess_table(tb);
    open_table("left.db"); open_table("right.db"); // TODO: change it seamlessly
    // TODO : 전역변수 이거 처리하기 (모든 코드 수정) -> extern Table tb[MAX_TABLE_NUM]; 관련 코드 모두 수정. 예를 들어 fd를, tb[0].fd  (0으로 하드코딩해도됨 <-  삽입/삭제/검색 부분 / 반면 join 에선 [0], [1] 등 인덱스 여러개 활용)




    /*****************************/
    
    while(scanf("%c", &user_interaction_input) != EOF){
        switch(user_interaction_input){
            case INSERT:
                printf("Enter key and value: ");
                scanf("%ld %s", &key_input, user_value_input);
                db_insert(key_input, user_value_input);
                printf("\ndb_insert_call_done\n");
                break;

            case FIND:
                scanf("%ld", &key_input);
                result_value_string = db_find(key_input);
                if (result_value_string) {
                    printf("Key: %ld, Value: %s\n", key_input, result_value_string);
                    free(result_value_string);
                }
                else {
                    printf("Not Exists\n");
                }
                printf("\ndb_find_call_done\n");
                fflush(stdout);
                break;

            case DELETE:
                scanf("%ld", &key_input);
                db_delete(key_input);
                printf("\ndb_delete_call_done\n");
                break;

            case QUIT:
                while (getchar() != (int)'\n');
                printf("\n\nProgram Finally Terminated.\n");
                return EXIT_SUCCESS;
                break;

            // case JOIN:
            //     printf("START   [db_join]\n");
            //     db_join(anyArgument);
            //     printf("END     [db_join]\n");
            //     break;  
        }
        while (getchar() != (int)'\n');
    }
    printf("\n");
    return 0;
}

// important -> do not remove below line
/**
 * 
 * table#1 에 {1,“a”}, {2,“b”}, {3,“c”} 가 저장되어 있고
 * table#2 에 {2,“1”}, {3,“2”}, {4,“3”} 이 저장되어 있다면
 * <2>, b, 1    줄바꿈
 * <3>, c, 2
 * 출력
 */
