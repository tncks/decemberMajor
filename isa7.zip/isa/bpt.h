#ifndef __BPT_H__
#define __BPT_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <inttypes.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <assert.h>
#define DEFAULT_HASH_TABLE_SIZE 16384 // Large prime number for better distribution   // Configurable parameters
#define MAX_RECORDS 10000             // Maximum number of records to handle
#define MAX_VALUE_LENGTH 120          // Maximum length of record value
#define MAX_PARTITIONS 16
#define N_WAY_PASS 3 // just? considering..  // END/Configurable parameters
#define LEAF_MAX 31
#define INTERNAL_MAX 248
#ifndef SIZE_INT64
#define SIZE_INT64 sizeof(int64_t)
#endif
#ifndef SIZE_OFFSET
#define SIZE_OFFSET sizeof(off_t)
#endif
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif
#ifndef FIX_SIZE
#define FIX_SIZE 120
#endif
#define MAX_TABLE_NUM 2
// join 을 위해, left, right 두 테이블 사용할 것이므로, 배열 사이즈 매크로 2로 설정함.

typedef struct record
{
    int64_t key;
    char value[FIX_SIZE];
} record;

typedef struct inter_record
{
    int64_t key;
    off_t p_offset;
} I_R;

typedef struct Page
{
    off_t parent_page_offset;
    int is_leaf;
    int num_of_keys;
    char reserved[104];
    off_t next_offset;
    union
    {
        I_R b_f[INTERNAL_MAX];
        record records[LEAF_MAX];
    };
} page;

typedef struct Header_Page
{
    off_t fpo;
    off_t rpo;
    int64_t num_of_pages;
    char reserved[4072];
} H_P;

typedef struct Table
{
    int fd;
    page *rt;
    H_P *hp;
} Table;

typedef enum
{
    LEFT,
    RIGHT
} Side;

typedef record element;

typedef struct BasicChainNode
{
    element data;
    struct BasicChainNode *next;
} BasicChainNode;

typedef struct Queue
{
    BasicChainNode *front;
    BasicChainNode *rear;
    int count;
} Queue;

typedef struct ResultLLNod
{
    record output_data_rec;
    void *next_rec;
} ResultLLNode;

// Advanced hash entry with more efficient structure
typedef struct HashEntry
{
    int64_t key;
    char value[MAX_VALUE_LENGTH];
    struct HashEntry *next;
} HashEntry;

// Improved hash table structure
typedef struct
{
    HashEntry **buckets;
    size_t size;
    size_t count; // capacity
} HashTable;
/**
 *
 * buckets: An array of pointers to linked lists (HashEntry).
 * size: The number of buckets in the hash table.
 * count(capacity): The maximum number of entries it can hold before resizing.
 */

// Partition Structure
typedef struct
{
    int64_t *keys;
    char **values;
    int size;
    int capacity;
} Partition;

// Multi-Phase Partitioning Context
typedef struct
{
    Partition *partitions;
    int num_partitions;
    size_t total_records;
} PartitionContext;

extern Table tb[MAX_TABLE_NUM];
extern char *savedName;

extern Side s;

void db_join();
int merge_join1();
// int merge_join2();
int64_t get_min_key_from_relation(Side s___);
int get_tot_tup_cnt(int64_t first_key);
void load_tables(void *param1, void *param2);
int checkRelationEmpty(Side s__);
void tuple_accumulate(int n, record *temp, page *p);
void fill_up_left_table_rand_rule_applied(int64_t manipulated, int64_t from, int64_t to, int64_t step); /* global scope side */
void fill_up_right_table_rand_rule_applied(int64_t manipulated, int64_t from, int64_t to, int64_t step);
// void init();
// int isempty();
// void enqueue(element data);
// element dequeue();
// int get_size_queue();
void preprocess_table(Table *_table_);
H_P *load_header(off_t off);
page *load_page(off_t off);
int open_table(char *pathname);
void reset(off_t off);
void freetouse(off_t fpo);
void usetofree(off_t wbf);
off_t new_page();
off_t find_leaf(int64_t key);
char *db_find(int64_t key);
int cut(int length);
void start_new_file(record rec);
int db_insert(int64_t key, char *value);
off_t insert_into_leaf(off_t leaf, record inst);
off_t insert_into_leaf_as(off_t leaf, record inst);
off_t insert_into_parent(off_t old, int64_t key, off_t newp);
int get_left_index(off_t left);
off_t insert_into_new_root(off_t old, int64_t key, off_t newp);
off_t insert_into_internal(off_t bumo, int left_index, int64_t key, off_t newp);
off_t insert_into_internal_as(off_t bumo, int left_index, int64_t key, off_t newp);
int db_delete(int64_t key);
void delete_entry(int64_t key, off_t deloff);
void redistribute_pages(off_t need_more, int nbor_index, off_t nbor_off, off_t par_off, int64_t k_prime, int k_prime_index);
void merge_pages(off_t will_be_coal, int nbor_index, off_t nbor_off, off_t par_off, int64_t k_prime);
void adjust_root(off_t deloff);
void remove_entry_from_page(int64_t key, off_t deloff);
uint64_t hash_(int64_t key, size_t table_size);
void *MemAlloc(size_t size);
HashTable *create_hash_table(size_t initial_size);
void hash_table_insert(HashTable *ht, int64_t key, const char *value);
HashEntry *hash_table_search(HashTable *ht, int64_t key);
void hash_join1(record *r, int size_r, record *s, int size_s, int64_t *output_keys_r, int64_t *output_keys_s);
void hash_join2();
void db_hash(void);
int get_num_tup(Side arg);
// void perform_experiment();
void compare_and_output(int64_t left_key, record left_record, int64_t right_key, record right_record);
void advance_to_next(page **p, off_t *offset, int *done);

#endif
