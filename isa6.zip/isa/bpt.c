#include "bpt.h"

Table tb[MAX_TABLE_NUM]; /** declared as extern in bpt.h  **/
char *savedName = NULL;  /** declared as extern in bpt.h  **/

Side s = LEFT; /** declared as extern in bpt.h  **/

Queue q_;
Queue *q = NULL;
int verbose = 0; // for debug // TODO: <- 삭제
// 아래 SEVEN 값 수정: 너무 큰값 설정시 컴퓨터 고장 / 도커 고장 날수도 있으니 제발 조심히 조심히 값 수정!
// threshold_MAX 값은 현재 몇? simultaneously 체크.
#ifndef SEVEN
#define SEVEN 7
#endif
const int64_t tuplecount = SEVEN; // TODO: <- 삭제 /* Number of tuples in each relation */
record lr[SEVEN];                 // tuple 7개 // TODO: <- 삭제 // 참고) SEVEN 매크로 값이 너무 크면 여기서 전역변수선언이 에러가 날 수 있음. Mem exceed error. // possible error point.
record rr[SEVEN];                 // tuple 7개 // TODO: <- 삭제 // 참고) SEVEN 매크로 값이 너무 크면 여기서 전역변수선언이 에러가 날 수 있음. Mem exceed error. // possible error point.

/****************************************************************/
/****************************************************************/

void db_join()
{
    // int clock_s = 0; // for performance, experimental purpose
    printf("[db_join] called.\n");
    int ret = merge_join();
    // print end clock time;
}

int merge_join()
{
    /** Now readonly **/
    int result = -1;  // default: -1 for return val. assume pessimistic failing merge_join case at first
    int test_cnt = 0; // for debug
    const int threshold_MAX = 18000; // todo: rm
    init(); // queue init (target: the global queue variable)
    /** Mutable (adjust if needed) **/
    /* local scope test */
    //
    //
    //
    //
    record *rRarray = NULL;
    record *rSarray = NULL;
    my_j_loader(&rRarray, &rSarray); 
    if (rRarray == NULL && rSarray == NULL)
        fprintf(stderr, "pointer is pointing null\n");
    /**찍어보는구간S */
    /*
    if(s == LEFT ) printf("LEFT 기준찍어보는구간시작\n");
    if(s == RIGHT) printf("RIGHT기준찍어보는구간시작\n");
    for(int k=0; k < get_tot_tup_cnt(get_min_key_from_relation(s)); k++) {
        if(s == LEFT )  printf("rarray[%d]: '%ld', '%s'\n", k, rRarray[k].key, rRarray[k].value);
        if(s == RIGHT ) printf("rarray[%d]: '%ld', '%s'\n", k, rSarray[k].key, rSarray[k].value);
    }
    */
    /**찍어보는구간E */
    //
    //
    //
    //
    //
    /** Now readonly **/
    void *ptr_R = rRarray; 
    void *ptr_S = rSarray; 
    int done = FALSE;
    record t_r;
    record t_s;
    record t_prime_s;
    ResultLLNode outputNode;
    ResultLLNode outputRightNode;
    outputNode.next_rec = &outputRightNode; // connection

    /** end of declaration part **/
    //  qsort(R_local) qsort(S_local);  // currently, for test: skip (모두 정렬되어 있다고 가정하고, 실 테스트 데이터 셋도 일단 정렬된 걸로 준비하였음) <- TODO: 나중에 이것도 보완해야함
    //  테스트셋이 정렬이 되어있지 않으면 오버플로우 난 것처럼, 결과가 이상하게 나올 수 있음에 주의.
    //  printf("[merge_join] Encountered the first while statement..\n");

    /** Now readonly **/
    while (ptr_R != NULL && ptr_S != NULL)
    {

        if (++test_cnt > threshold_MAX)
            break; // for debug: infinite loop case 점검용도

        if (ptr_S != NULL)
            memcpy(&t_s, ptr_S, sizeof(record));
        /**𝑆𝑠:={𝑡𝑠};**/ // replaced by enqueue.
        enqueue(t_s);   // ENQUEUE with item t_s (tuple of S)
        if ((*(((record *)ptr_S) + 1)).value[0] == 0)
        {
            done = TRUE; // ptr -> points target unchanged
            ptr_S = NULL;
        }
        else
        {
            ptr_S = ((record *)ptr_S) + 1; // ptr now points the next tuple of S
        }

        done = FALSE;

        while (!done && ptr_S != NULL)
        {

            if (ptr_S != NULL)
                memcpy(&t_prime_s, ptr_S, sizeof(record));
            if (t_prime_s.key == t_s.key)
            {
                /**𝑆𝑠:=𝑆𝑠 U {𝑡`𝑠};**/ // replaced by enqueue.
                enqueue(t_prime_s);   // ENQUEUE with item t_prime_s

                if ((*(((record *)ptr_S) + 1)).value[0] == 0)
                {
                    done = TRUE; // ptr -> points target unchanged
                    ptr_S = NULL;
                }
                else
                {
                    ptr_S = ((record *)ptr_S) + 1; // ptr now points the next tuple of S
                }
            }
            else
            {
                done = TRUE;
            }
        }

        if (ptr_R != NULL)
            memcpy(&t_r, ptr_R, sizeof(record));

        /** t_r.key < t_s.key **/
        while (ptr_R != NULL && t_r.key < t_s.key)
        {

            if ((*(((record *)ptr_R) + 1)).value[0] == 0)
            {
                done = TRUE;
                ptr_R = NULL;
            }
            else                               //
            {                                  //
                ptr_R = ((record *)ptr_R) + 1; //
            }
            if (ptr_R != NULL)
                memcpy(&t_r, ptr_R, sizeof(record));
        }

        /** t_r.key == t_s.key **/
        while (ptr_R != NULL && t_r.key == t_s.key)
        {

            int qLen = get_size_queue();
            for (int i = 0; i < qLen; i++)
            {
                record dq_val_S = dequeue(); // S
                outputNode.output_data_rec = dq_val_S;
                outputRightNode.output_data_rec = t_r;
                printf("output: ( %3ld, %-5s, %-5s )\n", outputNode.output_data_rec.key, outputNode.next_rec == NULL ? "NULL!" : ((struct ResultLLNod *)(outputNode.next_rec))->output_data_rec.value, outputNode.output_data_rec.value);
                result = 0;
            }
            if ((*(((record *)ptr_R) + 1)).value[0] == 0)
            {
                done = TRUE;
                ptr_R = NULL;
                break; /** B R E A K **/
            }
            else                               //
            {                                  //
                ptr_R = ((record *)ptr_R) + 1; //
            }
            if (ptr_R != NULL)
                memcpy(&t_r, ptr_R, sizeof(record));
        }
    }

    do {
        if(!isempty()) dequeue();
    } while(!isempty());

    if (verbose)
        printf("[merge_join] This function returned decimal '%d'. test_cnt: '%d'\n", result, test_cnt); // original

    /*****************************************************************/
    /*****************************************************************/
    /*****************************************************************/
    /*****************************************************************/
    /* global scope test */
    verbose = 1; // easy switch var for fast debug
    if (verbose)
        printf("\n");
    if (verbose)
        printf("global scope test .. start!\n");
    if (verbose)
        printf("----------------------------\n");
    verbose = 0;
    /** Now readonly **/
    result = -1;  // default: -1 for return val. assume pessimistic failing merge_join case at first
    test_cnt = 0; // for debug
    /** Mutable (adjust if needed) **/
    // call fill up functions respectively
    fill_up_left_table_rand_rule_applied();
    fill_up_right_table_rand_rule_applied();
    lr[SEVEN - 1].key = -9999 + SEVEN; // <- only hard coding
    memset(lr[SEVEN - 1].value, 0, sizeof(char) * FIX_SIZE);
    rr[SEVEN - 1].key = -9999 - SEVEN; // <- only hard coding
    memset(rr[SEVEN - 1].value, 0, sizeof(char) * FIX_SIZE);
    // hard coded (test purpose)
    // clock_s = 0; // for performance, experimental purpose
    /** Now readonly **/
    ptr_R = lr;
    ptr_S = rr;
    done = FALSE;

    /** end of global declaration and re-usage setting for local var part **/
    //  qsort(R_global) qsort(S_global);

    /** Now readonly **/
    while (ptr_R != NULL && ptr_S != NULL)
    {

        if (++test_cnt > threshold_MAX)
            break; // for debug: infinite loop case 점검용도

        if (ptr_S != NULL)
            memcpy(&t_s, ptr_S, sizeof(record));
        /**𝑆𝑠:={𝑡𝑠};**/ // replaced by enqueue.
        enqueue(t_s);   // ENQUEUE with item t_s (tuple of S)
        if ((*(((record *)ptr_S) + 1)).value[0] == 0)
        {
            done = TRUE; // ptr -> points target unchanged
            ptr_S = NULL;
        }
        else
        {
            ptr_S = ((record *)ptr_S) + 1; // ptr now points the next tuple of S
        }

        done = FALSE;

        while (!done && ptr_S != NULL)
        {

            if (ptr_S != NULL)
                memcpy(&t_prime_s, ptr_S, sizeof(record));
            if (t_prime_s.key == t_s.key)
            {
                /**𝑆𝑠:=𝑆𝑠 U {𝑡`𝑠};**/ // replaced by enqueue.
                enqueue(t_prime_s);   // ENQUEUE with item t_prime_s

                if ((*(((record *)ptr_S) + 1)).value[0] == 0)
                {
                    done = TRUE; // ptr -> points target unchanged
                    ptr_S = NULL;
                }
                else
                {
                    ptr_S = ((record *)ptr_S) + 1; // ptr now points the next tuple of S
                }
            }
            else
            {
                done = TRUE;
            }
        }

        if (ptr_R != NULL)
            memcpy(&t_r, ptr_R, sizeof(record));

        /** t_r.key < t_s.key **/
        while (ptr_R != NULL && t_r.key < t_s.key)
        {

            if ((*(((record *)ptr_R) + 1)).value[0] == 0)
            {
                done = TRUE;
                ptr_R = NULL;
            }
            else                               //
            {                                  //
                ptr_R = ((record *)ptr_R) + 1; //
            }
            if (ptr_R != NULL)
                memcpy(&t_r, ptr_R, sizeof(record));
        }

        /** t_r.key == t_s.key **/
        while (ptr_R != NULL && t_r.key == t_s.key)
        {

            int qLen = get_size_queue();
            for (int i = 0; i < qLen; i++)
            {
                record dq_val_S = dequeue(); // S
                outputNode.output_data_rec = dq_val_S;
                outputRightNode.output_data_rec = t_r;
                printf("output: ( %3ld, %-5s, %-5s )\n", outputNode.output_data_rec.key, outputNode.next_rec == NULL ? "NULL!" : ((struct ResultLLNod *)(outputNode.next_rec))->output_data_rec.value, outputNode.output_data_rec.value);
                result = 0;
            }
            if ((*(((record *)ptr_R) + 1)).value[0] == 0)
            {
                done = TRUE;
                ptr_R = NULL;
                break; /** B R E A K **/
            }
            else                               //
            {                                  //
                ptr_R = ((record *)ptr_R) + 1; //
            }
            if (ptr_R != NULL)
                memcpy(&t_r, ptr_R, sizeof(record));
        }
    }

    do {
        if(!isempty()) dequeue();
    } while(!isempty());

    if (verbose)
        printf("[merge_join] This function returned decimal '%d'. test_cnt: '%d'\n", result, test_cnt);

    free(rRarray); // free
    free(rSarray); // free
    return result;
}

void tuple_accumulate(int n, record *temp, page *p)
{
    record cur;
    for (int i = 0; i < n; i++, memset(&cur, 0, sizeof(record))) // for loop: is it really ok? currently self assuming ok, but still under final test
    {
        cur.key = p->records[i].key;
        int n = strlen(p->records[i].value);
        strncpy(cur.value, p->records[i].value, n);
        cur.value[n] = '\0';
        *(temp + i) = cur;
    }
}

int64_t get_min_key_from_relation(Side s___)
{
    // root 부터 시작하여, leaf 까지 쭉 내려감. leftmost leaf 의 min key 값 return

    int i = 0;
    int64_t min = -3;
    page *p;
    off_t loc = tb[s___].hp->rpo;
    p = load_page(loc);

    if (p->is_leaf) // load 하자마자 root 이자 leaf 성립? then (굉장히 예외적인 케이스.)
    {
        min = p->records[0].key;
        free(p);
        return min;
    }

    while (!p->is_leaf)
    {
        if (0 < p->num_of_keys)
        {
            min = p->b_f[0].key; // 일단 min 변수값 현재값을 받아와서 리턴할 값으로 미리 업데이트. under test.
        }
        loc = p->next_offset;
        free(p);
        p = load_page(loc);
    }

    if (p->is_leaf)
    {
        min = p->records[0].key;
    }

    free(p);
    return min;
}

int get_tot_tup_cnt(int64_t first_key)
{
    off_t fin = find_leaf(first_key); // LEFT 기준인가? 이거 고려
    // if(fin == 0???...) possible 예외처리?
    int done = FALSE;
    int tup_cnt = 0;

    do
    {
        page *p = load_page(fin);
        if (p == NULL)
            fprintf(stderr, "p is pointing NULL in do~while loop\n"); // todo add exception handle
        if (p->is_leaf)
        {
            if (p->next_offset == 0)
            {
                done = TRUE;
            }
            else
            {
                fin = p->next_offset;
            }

            tup_cnt += p->num_of_keys;
            free(p);
        }
        else
        {
            fprintf(stderr, "return 1000000\n");
            return 1000000; // TODO hardcoding
        }

    } while (done == FALSE);

    if(verbose) printf("tup_cnt: '%d'\tin [get_tot_tup_cnt]\n", tup_cnt); // todo remove this line
    return tup_cnt;
}

int checkRelationEmpty(Side s__)
{
    return FALSE;
}

// 함수 설명 및 용도: join 전 준비:  join 전체 파트에서 앞 부분. 전처리 및 데이터 로드 준비.
// disk paged file(relation data) -> in memory loader 함수
void my_j_loader(void *param1, void *param2)
{

    if (checkRelationEmpty(LEFT) == FALSE && checkRelationEmpty(RIGHT) == FALSE)
    {

        // relation is not empty.
        Side saved = s;
        s = LEFT;
        int done = FALSE;
        int64_t first_key = get_min_key_from_relation(s);
        int tup_cnt = get_tot_tup_cnt(first_key);
        tup_cnt++;
        if(verbose) fprintf(stdout, "debug: onceplused_tupcLeft: [%d]\n", tup_cnt);
        record *temp = (record *)calloc(tup_cnt, sizeof(record)); // 동적할당함 일단 (LEFT table) // TODO: free() and dealloc!
        record *temp2;

        if (temp == NULL)
        {
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }
        memset(temp, 0, tup_cnt * sizeof(record)); // 가볍게 초기화.
        /* preheader */

        off_t fin = find_leaf(first_key); // 그러나, if fin == 0 이라면? ...

        int j = 0;
        do
        {
            page *p = load_page(fin); // 한 페이지는 4096 (첫 반복문 진입시: 현재 k1~k31 , 미정이지만 n개 정도 데이터가 들어가있다고 볼 수있고, 첫 반복 stage이면 첫번째 page 가 로드된 상황)
            if (p == NULL)
                fprintf(stderr, "p is pointing NULL in do~while loop\n");
            if (!p->is_leaf)
                fprintf(stderr, "do~while loop: p->is_leaf : [%d]. in procedure, my_j_loader.\n", p->is_leaf);
            if (p->next_offset == 0) // if rightmost? then
            {
                done = TRUE; // set 종료조건
            }
            else
            {
                fin = p->next_offset; // 현재 대상의 바로 다음 4096 페이지, 즉 right leaf access 준비 fin update by fetching right sibling node page off
            }

            tuple_accumulate(p->num_of_keys, temp + j, p); // 함수 내부에서: 반복문이 끝날때까지 있는 튜플들을 모두 accumulate
            j += p->num_of_keys;
            free(p);

        } while (done == FALSE); // possible memory leak due to page *p // under investigation
        temp[j].key = -9999 - j - SEVEN;
        memset(temp[j].value, 0, sizeof(char) * FIX_SIZE);

        j = 0;
        *((record **)param1) = temp;

        /** **/

        s = RIGHT;
        done = FALSE;
        first_key = get_min_key_from_relation(s);
        tup_cnt = get_tot_tup_cnt(first_key);
        tup_cnt++;
        if(verbose) fprintf(stdout, "debug: onceplused_tupcRight: [%d]\n", tup_cnt);
        temp2 = (record *)calloc(tup_cnt, sizeof(record)); //  동적할당함 일단. // TODO: free() and dealloc!
        if (temp2 == NULL)
        {
            fprintf(stderr, "Memory allocation failed\n");
            free(temp);
            exit(EXIT_FAILURE);
        }
        memset(temp2, 0, tup_cnt * sizeof(record)); // 가볍게 초기화.
        /* preheader */

        fin = find_leaf(first_key); // 그러나, if fin == 0 이라면? ...

        j = 0;
        do
        {
            page *p = load_page(fin); // 한 페이지는 4096 (첫 반복문 진입시: 현재 k1~k31 , 미정이지만 n개 정도 데이터가 들어가있다고 볼 수있고, 첫 반복 stage여서 첫번째 page 가 로드된 상황)
            if (p == NULL)
                fprintf(stderr, "p is pointing NULL in do~while loop\n");
            if (!p->is_leaf)
                fprintf(stderr, "do~while loop: p->is_leaf : [%d]. in procedure, my_j_loader.\n", p->is_leaf);
            if (p->next_offset == 0) // if rightmost? then
            {
                done = TRUE; // set 종료조건
            }
            else
            {
                fin = p->next_offset; // 현재 대상의 바로 다음 4096 페이지, 즉 right leaf access 준비 fin update by fetching right sibling node page off
            }

            tuple_accumulate(p->num_of_keys, temp2 + j, p); // 함수 내부에서: 반복문이 끝날때까지 있는 튜플들을 모두 accumulate
            j += p->num_of_keys;
            free(p);

        } while (done == FALSE); // possible memory leak due to page *p // under investigation
        temp2[j].key = -99999 - j + SEVEN;
        memset(temp2[j].value, 0, sizeof(char) * FIX_SIZE);

        j = 0;
        *((record **)param2) = temp2;
        s = saved;
    }
    else
    {
        /**
         * relation empty case.
         * todo:  join 을 할 필요 없도록 처리. join 출력결과도  나오는게 없도록 설계..
         *
         * nothing to load.
         * nothing to assign.
         */
        return;
    }
}
//

//
//
/*** */
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

//
//
//
/*** */
//
//

void preprocess_table(Table *_table_)
{
    int i;
    for (i = 0; i < MAX_TABLE_NUM; i++)
    {
        _table_[i].rt = NULL;
        _table_[i].fd = -1;
    }
}

H_P *load_header(off_t off)
{
    H_P *newhp = (H_P *)calloc(1, sizeof(H_P)); // TODO: free() and dealloc!
    if (newhp == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n");
        return NULL;
    }

    if (sizeof(H_P) > pread(tb[s].fd, newhp, sizeof(H_P), 0))
    {
        return NULL;
    }
    return newhp;
}

page *load_page(off_t off)
{
    page *load = (page *)calloc(1, sizeof(page)); // TODO: free() and dealloc!
    if (load == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n");
        return NULL;
    }

    if (sizeof(page) > pread(tb[s].fd, load, sizeof(page), off))
    {
        if (off % sizeof(page) != 0)
            fprintf(stderr, "load fail : page offset : %2ld\n", (int64_t)off);
        if (off % sizeof(page) != 0)
            fprintf(stderr, "load fail : page offset error\n");
        return NULL;
    }
    return load;
}

int open_table(char *pathname)
{
    static int count = 0;
    if (count == 0) // 조건 참? open_table 함수 처음 호출되었을 시에만 해당. if true. then.
    {
        savedName = pathname;                                                    // 전역변수는 이제 open_table 함수 처음 호출되었을 시 기준으로, 프로그램끝날때까지 pathName(left)테이블이름으로 쭉 잡히게됨.
        tb[LEFT].fd = open(savedName, O_RDWR | O_CREAT | O_EXCL | O_SYNC, 0775); // pathName 여기서부터 더이상 활용 안함.
        tb[LEFT].hp = (H_P *)calloc(1, sizeof(H_P));                             // TODO: free() and dealloc!
        if (tb[LEFT].hp == NULL)
        {
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }

        if (tb[LEFT].fd > 0)
        {
            printf("Can not find the './%s'\n", savedName);
            printf("Automatically New File './%s' has been created.\n", savedName);
            tb[LEFT].hp->fpo = 0;
            tb[LEFT].hp->num_of_pages = 1;
            tb[LEFT].hp->rpo = 0;
            pwrite(tb[LEFT].fd, tb[LEFT].hp, sizeof(H_P), 0);
            free(tb[LEFT].hp);
            tb[LEFT].hp = load_header(0);
            count = 1;
            return 0;
        }
        tb[LEFT].fd = open(savedName, O_RDWR | O_SYNC);
        if (tb[LEFT].fd > 0)
        {
            printf("Read Already Existed File.\n");
            if (sizeof(H_P) > pread(tb[LEFT].fd, tb[LEFT].hp, sizeof(H_P), 0))
            {
                return -1;
            }
            off_t r_o = tb[LEFT].hp->rpo;
            tb[LEFT].rt = load_page(r_o);
            count = 1;
            return 0;
        }
        else
        {
            count = 1;
            return -1;
        }
    }
    else
    {
        tb[RIGHT].fd = open(pathname, O_RDWR | O_CREAT | O_EXCL | O_SYNC, 0775); // savedName(<-left이므로) 의도적으로 활용 안함. 여기서는 right 를 열고처리할것이기때문.
        tb[RIGHT].hp = (H_P *)calloc(1, sizeof(H_P));                            // TODO: free() and dealloc!
        if (tb[RIGHT].hp == NULL)
        {
            fprintf(stderr, "Memory allocation failed\n");
            exit(EXIT_FAILURE);
        }

        if (tb[RIGHT].fd > 0)
        {
            printf("Can not find the './%s'\n", pathname);
            printf("Automatically New File './%s' has been created.\n", pathname);
            tb[RIGHT].hp->fpo = 0;
            tb[RIGHT].hp->num_of_pages = 1;
            tb[RIGHT].hp->rpo = 0;
            pwrite(tb[RIGHT].fd, tb[RIGHT].hp, sizeof(H_P), 0);
            free(tb[RIGHT].hp);
            tb[RIGHT].hp = load_header(0);
            count = 1;
            return 0;
        }
        tb[RIGHT].fd = open(pathname, O_RDWR | O_SYNC);
        if (tb[RIGHT].fd > 0)
        {
            printf("Read Already Existed File.\n");
            if (sizeof(H_P) > pread(tb[RIGHT].fd, tb[RIGHT].hp, sizeof(H_P), 0))
            {
                return -1;
            }
            off_t r_o = tb[RIGHT].hp->rpo;
            tb[RIGHT].rt = load_page(r_o);
            count = 1;
            return 0;
        }
        else
        {
            count = 1;
            return -1;
        }
    }
}

void reset(off_t off)
{
    page *reset;
    reset = (page *)calloc(1, sizeof(page)); // TODO: free() and dealloc!
    if (reset == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }

    reset->parent_page_offset = 0;
    reset->is_leaf = 0;
    reset->num_of_keys = 0;
    reset->next_offset = 0;
    pwrite(tb[s].fd, reset, sizeof(page), off);
    free(reset);
    return;
}

void freetouse(off_t fpo)
{
    page *reset;
    reset = load_page(fpo);
    reset->parent_page_offset = 0;
    reset->is_leaf = 0;
    reset->num_of_keys = 0;
    reset->next_offset = 0;
    pwrite(tb[s].fd, reset, sizeof(page), fpo);
    free(reset);
    return;
}

void usetofree(off_t wbf)
{
    page *utf = load_page(wbf);
    utf->parent_page_offset = tb[s].hp->fpo;
    utf->is_leaf = 0;
    utf->num_of_keys = 0;
    utf->next_offset = 0;
    pwrite(tb[s].fd, utf, sizeof(page), wbf);
    free(utf);
    tb[s].hp->fpo = wbf;
    pwrite(tb[s].fd, tb[s].hp, sizeof(tb[s].hp), 0);
    free(tb[s].hp);
    tb[s].hp = load_header(0);
    return;
}

off_t new_page()
{
    off_t newp;
    page *np;
    off_t prev;
    if (tb[s].hp->fpo != 0)
    {
        newp = tb[s].hp->fpo;
        np = load_page(newp);
        tb[s].hp->fpo = np->parent_page_offset;
        pwrite(tb[s].fd, tb[s].hp, sizeof(tb[s].hp), 0);
        free(tb[s].hp);
        tb[s].hp = load_header(0);
        free(np);
        freetouse(newp);
        return newp;
    }
    // change previous offset to 0 is needed
    newp = lseek(tb[s].fd, 0, SEEK_END);

    reset(newp);
    tb[s].hp->num_of_pages++;
    pwrite(tb[s].fd, tb[s].hp, sizeof(H_P), 0);
    free(tb[s].hp);
    tb[s].hp = load_header(0);
    return newp;
}

off_t find_leaf(int64_t key)
{
    int i = 0;
    int threshold = 0;
    page *p;
    off_t loc = tb[s].hp->rpo;
    int __verbose__ = 0; // toggle this if want. local var.

    if (tb[s].rt != NULL && __verbose__)
        fprintf(stdout, "[find_leaf]  current loc: %ld, current num_of_pages: %ld, key = %ld, right = %ld, is_leaf = %d, now_root = %ld\n", loc, tb[s].hp->num_of_pages,
                tb[s].rt->b_f[0].key, tb[s].rt->b_f[0].p_offset, tb[s].rt->is_leaf, tb[s].hp->rpo);

    if (tb[s].rt == NULL)
    {
        int verbose2 = 1;
        if (verbose2)
            fprintf(stdout, "[find_leaf] Empty tree.\n");
        return 0;
    }
    if (loc % sizeof(page) == 0)
        p = load_page(loc);

    while (!p->is_leaf)
    {
        i = 0;
        threshold++;
        if (threshold > 10000)
        {
            fprintf(stderr, "Error status found: (current loc: %ld, return val: %ld, exceeded threshold, %d)\n", loc, loc + 1, threshold);
            return loc + 1;
        }

        while (i < p->num_of_keys)
        {
            if (key >= p->b_f[i].key)
                i++;
            else
                break;
        }
        if (i == 0)
            loc = p->next_offset;
        else
        {
            if (!p->is_leaf)
            {
                if ((p->b_f[i - 1].p_offset) % sizeof(page) == 0)
                    loc = p->b_f[i - 1].p_offset;
            }
        }

        if (loc == 0)
            return NULL;

        free(p);
        p = NULL;
        if (loc % sizeof(page) == 0)
            p = load_page(loc);
    }

    free(p);
    return loc;
}

char *db_find(int64_t key)
{
    char *value = (char *)malloc(sizeof(char) * FIX_SIZE); // TODO: free() and dealloc!
    if (value == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n");
        return NULL;
    }

    int i = 0;
    off_t fin = find_leaf(key);
    if (fin == 0)
    {
        free(value);
        return NULL;
    }
    page *p = load_page(fin);
    if (p == NULL)
    {
        fprintf(stderr, "bpt.c : page *p = load_page(fin); at db_find procedure. p is pointing NULL\n"); // seg point?
        free(value);
        exit(EXIT_FAILURE);
    }

    for (; i < p->num_of_keys; i++)
    {
        if (p->records[i].key == key)
            break;
    }
    if (i == p->num_of_keys)
    {
        free(p);
        free(value);
        return NULL;
    }
    else
    {
        int n = strlen(p->records[i].value);
        strncpy(value, p->records[i].value, n);
        value[n] = '\0';
        free(p);
        return value;
    }
}

int cut(int length)
{
    if (length % 2 == 0)
        return length / 2;
    else
        return length / 2 + 1;
}

void start_new_file(record rec)
{
    off_t ro;
    ro = new_page();
    tb[s].rt = load_page(ro);
    tb[s].hp->rpo = ro;
    pwrite(tb[s].fd, tb[s].hp, sizeof(H_P), 0);
    free(tb[s].hp);
    tb[s].hp = load_header(0);
    tb[s].rt->num_of_keys = 1;
    tb[s].rt->is_leaf = 1;
    tb[s].rt->records[0] = rec;
    pwrite(tb[s].fd, tb[s].rt, sizeof(page), tb[s].hp->rpo);
    free(tb[s].rt);
    tb[s].rt = load_page(tb[s].hp->rpo);
    int verbose_ = 1;
    if (verbose_)
        printf("[start_new_file] new file is made.\n");
}

int db_insert(int64_t key, char *value)
{

    record nr;
    nr.key = key;
    int n = strlen(value);
    strncpy(nr.value, value, n);
    nr.value[n] = '\0';
    if (tb[s].rt == NULL || (tb[s].hp->num_of_pages == 1 && tb[s].rt != NULL && tb[s].rt->is_leaf == 0))
    {
        start_new_file(nr);
        return 0;
    }

    char *dupcheck;
    dupcheck = db_find(key);
    if (dupcheck != NULL)
    {
        printf("[find_leaf] key '%ld' already exists, insertion cancelled.\n", key);
        free(dupcheck);
        return -1;
    }
    free(dupcheck);

    fprintf(stderr, "key: [ %ld ]\n", key);
    off_t leaf = find_leaf(key);

    page *leafp = load_page(leaf);

    if (leafp->num_of_keys < LEAF_MAX)
    {
        insert_into_leaf(leaf, nr);
        free(leafp);
        return 0;
    }

    insert_into_leaf_as(leaf, nr);
    free(leafp);
    return 0;
}

off_t insert_into_leaf(off_t leaf, record inst)
{
    page *p = load_page(leaf);
    if (p->is_leaf == 0)
        fprintf(stderr, "insert_into_leaf error : it is not leaf page\n");
    int i, insertion_point;
    insertion_point = 0;
    while (insertion_point < p->num_of_keys && p->records[insertion_point].key < inst.key)
    {
        insertion_point++;
    }
    for (i = p->num_of_keys; i > insertion_point; i--)
    {
        p->records[i] = p->records[i - 1];
    }
    p->records[insertion_point] = inst;
    p->num_of_keys++;
    pwrite(tb[s].fd, p, sizeof(page), leaf);
    // printf("insertion %ld is complete %d, %ld\n", inst.key, p->num_of_keys, leaf);
    free(p);
    return leaf;
}

off_t insert_into_leaf_as(off_t leaf, record inst)
{
    off_t new_leaf;
    record *temp;
    int insertion_index, split, i, j;
    int64_t new_key;
    new_leaf = new_page();
    // printf("\n%ld is new_leaf offset\n\n", new_leaf);
    page *nl = load_page(new_leaf);
    nl->is_leaf = 1;
    temp = (record *)calloc(LEAF_MAX + 1, sizeof(record)); // TODO: free() and dealloc!
    if (temp == NULL)
    {
        perror("Temporary records array(mem alloc failed)\n");
        free(nl);
        exit(EXIT_FAILURE);
    }
    insertion_index = 0;
    page *ol = load_page(leaf);
    while (insertion_index < LEAF_MAX && ol->records[insertion_index].key < inst.key)
    {
        insertion_index++;
    }
    for (i = 0, j = 0; i < ol->num_of_keys; i++, j++)
    {
        if (j == insertion_index)
            j++;
        temp[j] = ol->records[i];
    }
    temp[insertion_index] = inst;
    ol->num_of_keys = 0;
    split = cut(LEAF_MAX);

    for (i = 0; i < split; i++)
    {
        ol->records[i] = temp[i];
        ol->num_of_keys++;
    }

    for (i = split, j = 0; i < LEAF_MAX + 1; i++, j++)
    {
        nl->records[j] = temp[i];
        nl->num_of_keys++;
    }

    free(temp);

    nl->next_offset = ol->next_offset;
    ol->next_offset = new_leaf;

    for (i = ol->num_of_keys; i < LEAF_MAX; i++)
    {
        ol->records[i].key = 0;
        // strcpy(ol->records[i].value, NULL);
    }

    for (i = nl->num_of_keys; i < LEAF_MAX; i++)
    {
        nl->records[i].key = 0;
        // strcpy(nl->records[i].value, NULL);
    }

    nl->parent_page_offset = ol->parent_page_offset;
    new_key = nl->records[0].key;

    pwrite(tb[s].fd, nl, sizeof(page), new_leaf);
    pwrite(tb[s].fd, ol, sizeof(page), leaf);
    free(ol);
    free(nl);
    // printf("split_leaf is complete\n");

    return insert_into_parent(leaf, new_key, new_leaf);
}

off_t insert_into_parent(off_t old, int64_t key, off_t newp)
{

    int left_index;
    off_t bumo;
    page *left;
    left = load_page(old);

    bumo = left->parent_page_offset;
    free(left);

    if (bumo == 0)
        return insert_into_new_root(old, key, newp);

    left_index = get_left_index(old);

    page *parent = load_page(bumo);
    // printf("\nbumo is %ld\n", bumo);
    if (parent->num_of_keys < INTERNAL_MAX)
    {
        free(parent);
        // printf("\nuntil here is ok\n");
        return insert_into_internal(bumo, left_index, key, newp);
    }
    free(parent);
    return insert_into_internal_as(bumo, left_index, key, newp);
}

int get_left_index(off_t left)
{
    page *child = load_page(left);
    off_t po = child->parent_page_offset;
    free(child);
    page *parent = load_page(po);
    int i = 0;
    if (left == parent->next_offset)
        return -1;
    for (; i < parent->num_of_keys; i++)
    {
        if (parent->b_f[i].p_offset == left)
            break;
    }

    if (i == parent->num_of_keys)
    {
        free(parent);
        return -10;
    }
    free(parent);
    return i;
}

off_t insert_into_new_root(off_t old, int64_t key, off_t newp)
{

    off_t new_root;
    new_root = new_page();
    page *nr = load_page(new_root);
    nr->b_f[0].key = key;
    nr->next_offset = old;
    nr->b_f[0].p_offset = newp;
    nr->num_of_keys++;
    nr->is_leaf = 0;
    // printf("key = %ld, old = %ld, new = %ld, nok = %d, nr = %ld\n", key, old, newp,
    //   nr->num_of_keys, new_root);
    page *left = load_page(old);
    page *right = load_page(newp);
    left->parent_page_offset = new_root;
    right->parent_page_offset = new_root;
    pwrite(tb[s].fd, nr, sizeof(page), new_root);
    pwrite(tb[s].fd, left, sizeof(page), old);
    pwrite(tb[s].fd, right, sizeof(page), newp);
    free(nr);
    nr = load_page(new_root);
    tb[s].rt = nr;
    tb[s].hp->rpo = new_root;
    pwrite(tb[s].fd, tb[s].hp, sizeof(H_P), 0);
    free(tb[s].hp);
    tb[s].hp = load_header(0);
    free(left);
    free(right);
    return new_root;
}

off_t insert_into_internal(off_t bumo, int left_index, int64_t key, off_t newp)
{

    page *parent = load_page(bumo);
    int i;

    for (i = parent->num_of_keys; i > left_index + 1; i--)
    {
        parent->b_f[i] = parent->b_f[i - 1];
    }
    parent->b_f[left_index + 1].key = key;
    parent->b_f[left_index + 1].p_offset = newp;
    parent->num_of_keys++;
    pwrite(tb[s].fd, parent, sizeof(page), bumo);
    free(parent);
    if (bumo == tb[s].hp->rpo)
    {
        free(tb[s].rt);
        tb[s].rt = load_page(bumo);
        // printf("\ntb[s].rt->numofkeys%lld\n", tb[s].rt->num_of_keys);
    }
    return tb[s].hp->rpo;
}

off_t insert_into_internal_as(off_t bumo, int left_index, int64_t key, off_t newp)
{

    int i, j, split;
    int64_t k_prime;
    off_t new_p, child;
    I_R *temp;

    temp = (I_R *)calloc(INTERNAL_MAX + 1, sizeof(I_R)); // TODO: free() and dealloc!
    if (temp == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }

    page *old_parent = load_page(bumo);

    for (i = 0, j = 0; i < old_parent->num_of_keys; i++, j++)
    {
        if (j == left_index + 1)
            j++;
        temp[j] = old_parent->b_f[i];
    }

    temp[left_index + 1].key = key;
    temp[left_index + 1].p_offset = newp;

    split = cut(INTERNAL_MAX);
    new_p = new_page();
    page *new_parent = load_page(new_p);
    old_parent->num_of_keys = 0;
    for (i = 0; i < split; i++)
    {
        old_parent->b_f[i] = temp[i];
        old_parent->num_of_keys++;
    }
    k_prime = temp[i].key;
    new_parent->next_offset = temp[i].p_offset;
    for (++i, j = 0; i < INTERNAL_MAX + 1; i++, j++)
    {
        new_parent->b_f[j] = temp[i];
        new_parent->num_of_keys++;
    }

    new_parent->parent_page_offset = old_parent->parent_page_offset;
    page *nn;
    nn = load_page(new_parent->next_offset);
    nn->parent_page_offset = new_p;
    pwrite(tb[s].fd, nn, sizeof(page), new_parent->next_offset);
    free(nn);
    for (i = 0; i < new_parent->num_of_keys; i++)
    {
        child = new_parent->b_f[i].p_offset;
        page *ch = load_page(child);
        ch->parent_page_offset = new_p;
        pwrite(tb[s].fd, ch, sizeof(page), child);
        free(ch);
    }

    pwrite(tb[s].fd, old_parent, sizeof(page), bumo);
    pwrite(tb[s].fd, new_parent, sizeof(page), new_p);
    free(old_parent);
    free(new_parent);
    free(temp);
    // printf("split internal is complete\n");
    return insert_into_parent(bumo, k_prime, new_p);
}

int db_delete(int64_t key)
{

    if (tb[s].rt->num_of_keys == 0)
    {
        // printf("root is empty\n");
        return -1;
    }
    char *check = db_find(key);
    if (check == NULL)
    {
        free(check);
        // printf("There are no key to delete\n");
        return -1;
    }
    free(check);
    off_t deloff = find_leaf(key);
    delete_entry(key, deloff);
    return 0;

} // fin

void delete_entry(int64_t key, off_t deloff)
{

    remove_entry_from_page(key, deloff);

    if (deloff == tb[s].hp->rpo)
    {
        adjust_root(deloff);
        return;
    }
    page *not_enough = load_page(deloff);
    int check = not_enough->is_leaf ? cut(LEAF_MAX) : cut(INTERNAL_MAX);
    if (not_enough->num_of_keys >= check)
    {
        free(not_enough);
        // printf("just delete\n");
        return;
    }

    int neighbor_index, k_prime_index;
    off_t neighbor_offset, parent_offset;
    int64_t k_prime;
    parent_offset = not_enough->parent_page_offset;
    page *parent = load_page(parent_offset);

    if (parent->next_offset == deloff)
    {
        neighbor_index = -2;
        neighbor_offset = parent->b_f[0].p_offset;
        k_prime = parent->b_f[0].key;
        k_prime_index = 0;
    }
    else if (parent->b_f[0].p_offset == deloff)
    {
        neighbor_index = -1;
        neighbor_offset = parent->next_offset;
        k_prime_index = 0;
        k_prime = parent->b_f[0].key;
    }
    else
    {
        int i;

        for (i = 0; i <= parent->num_of_keys; i++)
            if (parent->b_f[i].p_offset == deloff)
                break;
        neighbor_index = i - 1;
        neighbor_offset = parent->b_f[i - 1].p_offset;
        k_prime_index = i;
        k_prime = parent->b_f[i].key;
    }

    page *neighbor = load_page(neighbor_offset);
    int max = not_enough->is_leaf ? LEAF_MAX : INTERNAL_MAX - 1;
    int why = neighbor->num_of_keys + not_enough->num_of_keys;
    // printf("%d %d\n",why, max);
    if (why <= max)
    {
        free(not_enough);
        free(parent);
        free(neighbor);
        merge_pages(deloff, neighbor_index, neighbor_offset, parent_offset, k_prime);
    }
    else
    {
        free(not_enough);
        free(parent);
        free(neighbor);
        redistribute_pages(deloff, neighbor_index, neighbor_offset, parent_offset, k_prime, k_prime_index);
    }

    return;
}
void redistribute_pages(off_t need_more, int nbor_index, off_t nbor_off, off_t par_off, int64_t k_prime, int k_prime_index)
{

    page *need, *nbor, *parent;
    int i;
    need = load_page(need_more);
    nbor = load_page(nbor_off);
    parent = load_page(par_off);
    if (nbor_index != -2)
    {

        if (!need->is_leaf)
        {
            // printf("redis average interal\n");
            for (i = need->num_of_keys; i > 0; i--)
                need->b_f[i] = need->b_f[i - 1];

            need->b_f[0].key = k_prime;
            need->b_f[0].p_offset = need->next_offset;
            need->next_offset = nbor->b_f[nbor->num_of_keys - 1].p_offset;
            page *child = load_page(need->next_offset);
            child->parent_page_offset = need_more;
            pwrite(tb[s].fd, child, sizeof(page), need->next_offset);
            free(child);
            parent->b_f[k_prime_index].key = nbor->b_f[nbor->num_of_keys - 1].key;
        }
        else
        {
            // printf("redis average leaf\n");
            for (i = need->num_of_keys; i > 0; i--)
            {
                need->records[i] = need->records[i - 1];
            }
            need->records[0] = nbor->records[nbor->num_of_keys - 1];
            nbor->records[nbor->num_of_keys - 1].key = 0;
            parent->b_f[k_prime_index].key = need->records[0].key;
        }
    }
    else
    {
        //
        if (need->is_leaf)
        {
            // printf("redis leftmost leaf\n");
            need->records[need->num_of_keys] = nbor->records[0];
            for (i = 0; i < nbor->num_of_keys - 1; i++)
                nbor->records[i] = nbor->records[i + 1];
            parent->b_f[k_prime_index].key = nbor->records[0].key;
        }
        else
        {
            // printf("redis leftmost internal\n");
            need->b_f[need->num_of_keys].key = k_prime;
            need->b_f[need->num_of_keys].p_offset = nbor->next_offset;
            page *child = load_page(need->b_f[need->num_of_keys].p_offset);
            child->parent_page_offset = need_more;
            pwrite(tb[s].fd, child, sizeof(page), need->b_f[need->num_of_keys].p_offset);
            free(child);

            parent->b_f[k_prime_index].key = nbor->b_f[0].key;
            nbor->next_offset = nbor->b_f[0].p_offset;
            for (i = 0; i < nbor->num_of_keys - 1; i++)
                nbor->b_f[i] = nbor->b_f[i + 1];
        }
    }
    nbor->num_of_keys--;
    need->num_of_keys++;
    pwrite(tb[s].fd, parent, sizeof(page), par_off);
    pwrite(tb[s].fd, nbor, sizeof(page), nbor_off);
    pwrite(tb[s].fd, need, sizeof(page), need_more);
    free(parent);
    free(nbor);
    free(need);
    return;
}

void merge_pages(off_t will_be_coal, int nbor_index, off_t nbor_off, off_t par_off, int64_t k_prime)
{

    page *wbc, *nbor, *parent;
    off_t newp, wbf;

    if (nbor_index == -2)
    {
        // printf("leftmost\n");
        wbc = load_page(nbor_off);
        nbor = load_page(will_be_coal);
        parent = load_page(par_off);
        newp = will_be_coal;
        wbf = nbor_off;
    }
    else
    {
        wbc = load_page(will_be_coal);
        nbor = load_page(nbor_off);
        parent = load_page(par_off);
        newp = nbor_off;
        wbf = will_be_coal;
    }

    int point = nbor->num_of_keys;
    int le = wbc->num_of_keys;
    int i, j;
    if (!wbc->is_leaf)
    {
        // printf("coal internal\n");
        nbor->b_f[point].key = k_prime;
        nbor->b_f[point].p_offset = wbc->next_offset;
        nbor->num_of_keys++;

        for (i = point + 1, j = 0; j < le; i++, j++)
        {
            nbor->b_f[i] = wbc->b_f[j];
            nbor->num_of_keys++;
            wbc->num_of_keys--;
        }

        for (i = point; i < nbor->num_of_keys; i++)
        {
            page *child = load_page(nbor->b_f[i].p_offset);
            child->parent_page_offset = newp;
            pwrite(tb[s].fd, child, sizeof(page), nbor->b_f[i].p_offset);
            free(child);
        }
    }
    else
    {
        // printf("coal leaf\n");
        int range = wbc->num_of_keys;
        for (i = point, j = 0; j < range; i++, j++)
        {

            nbor->records[i] = wbc->records[j];
            nbor->num_of_keys++;
            wbc->num_of_keys--;
        }
        nbor->next_offset = wbc->next_offset;
    }
    pwrite(tb[s].fd, nbor, sizeof(page), newp);

    delete_entry(k_prime, par_off);
    free(wbc);
    usetofree(wbf);
    free(nbor);
    free(parent);
    return;

} // fin

void adjust_root(off_t deloff)
{

    if (tb[s].rt->num_of_keys > 0)
        return;
    if (!tb[s].rt->is_leaf)
    {
        off_t nr = tb[s].rt->next_offset;
        page *nroot = load_page(nr);
        nroot->parent_page_offset = 0;
        usetofree(tb[s].hp->rpo);
        tb[s].hp->rpo = nr;
        pwrite(tb[s].fd, tb[s].hp, sizeof(H_P), 0);
        free(tb[s].hp);
        tb[s].hp = load_header(0);

        pwrite(tb[s].fd, nroot, sizeof(page), nr);
        free(nroot);
        free(tb[s].rt);
        tb[s].rt = load_page(nr);

        return;
    }
    else
    {
        free(tb[s].rt);
        tb[s].rt = NULL;
        usetofree(tb[s].hp->rpo);
        tb[s].hp->rpo = 0;
        pwrite(tb[s].fd, tb[s].hp, sizeof(tb[s].hp), 0);
        free(tb[s].hp);
        tb[s].hp = load_header(0);
        return;
    }
} // fin

void remove_entry_from_page(int64_t key, off_t deloff)
{

    int i = 0;
    page *lp = load_page(deloff);
    if (lp->is_leaf)
    {
        // printf("remove leaf key %ld\n", key);
        while (lp->records[i].key != key)
            i++;

        for (++i; i < lp->num_of_keys; i++)
            lp->records[i - 1] = lp->records[i];
        lp->num_of_keys--;
        pwrite(tb[s].fd, lp, sizeof(page), deloff);
        if (deloff == tb[s].hp->rpo)
        {
            free(lp);
            free(tb[s].rt);
            tb[s].rt = load_page(deloff);
            return;
        }

        free(lp);
        return;
    }
    else
    {
        // printf("remove interanl key %ld\n", key);
        while (lp->b_f[i].key != key)
            i++;
        for (++i; i < lp->num_of_keys; i++)
            lp->b_f[i - 1] = lp->b_f[i];
        lp->num_of_keys--;
        pwrite(tb[s].fd, lp, sizeof(page), deloff);
        if (deloff == tb[s].hp->rpo)
        {
            free(lp);
            free(tb[s].rt);
            tb[s].rt = load_page(deloff);
            return;
        }

        free(lp);
        return;
    }
}

void init()
{
    q = &q_;
    q->front = q->rear = NULL;
    q->count = 0;
}

int isempty()
{
    return (q->count == 0);
}

int get_size_queue()
{
    return q->count;
}

void enqueue(element data)
{
    BasicChainNode *newNode = (BasicChainNode *)malloc(sizeof(BasicChainNode)); // TODO: free() and dealloc!
    if (newNode == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }

    newNode->data = data;
    newNode->next = NULL;

    if (isempty()) // 큐가 비어있을 때
    {
        q->front = newNode;
    }
    else
    {
        q->rear->next = newNode; // 맨 뒤의 다음을 newNode 로 설정
    }
    q->rear = newNode; // rear 포인터를 방금 삽입한 newNode 로 이동
    q->count++;        // 큐 안의 노드 개수 1 증가
    if (verbose)
        printf("enqueue sucessfully done.\n");
}

element dequeue()
{
    element data;
    BasicChainNode *ptr;
    if (isempty())
    {
        printf("queue empty. error case.\n");
        memset(&data, 0, sizeof(element));
        return data;
    }
    ptr = q->front;       // 꺼낼 노드를 ptr 설정
    data = ptr->data;     // 반환할 data 변수에 꺼낼 노드의 데이터를 복사
    q->front = ptr->next; // front 포인터를 꺼낼 노드의 다음으로 이동
    free(ptr);            // ptr 해제 (꺼낸 노드 해제)
    q->count--;           // 큐 안의 노드 개수 1 감소

    if (verbose)
        printf("dequeue sucessfully done.\n");
    return data;
}

// global 접근이 많은 함수들. (global scope test side..)
void fill_up_left_table_rand_rule_applied()
{
    srand(time(NULL));
    char ipsum[FIX_SIZE];
    memset(ipsum, 0, sizeof(char) * FIX_SIZE);
    for (int64_t i = 0; i < tuplecount; ++i)
    {
        // key in [20, SEVEN+20]
        int64_t key = i + 20;
        int random_type = rand() % 2;
        if (random_type == 0)
        {
            ipsum[0] = 65 + rand() % 26;
        }
        else
        {
            ipsum[0] = 97 + rand() % 26;
        }
        for (int j = 1; j < 3; ++j)
        {
            random_type = rand() % 3;
            if (random_type == 0)
            {
                ipsum[j] = 65 + rand() % 26;
            }
            else if (random_type == 1)
            {
                ipsum[j] = 97 + rand() % 26;
            }
            else
            {
                ipsum[j] = 48 + rand() % 10;
            }
        }
        ipsum[3] = '\0';

        // temporary version
        lr[(int)i].key = key; // 참고로 lr 은 전역변수로 사용되는중.
        strncpy(lr[(int)i].value, ipsum, 3);
        lr[(int)i].value[3] = '\0';

        // db_insert(key, ipsum); // TODO 주석해제하자. '//' 를 지우기
    }
}

void fill_up_right_table_rand_rule_applied()
{
    char ipsum[FIX_SIZE];
    memset(ipsum, 0, sizeof(char) * FIX_SIZE);
    for (int64_t i = 0; i < tuplecount; ++i)
    {
        // key in [20, SEVEN+20]
        int64_t key = i + 20;
        int random_type = rand() % 2;
        if (random_type == 0)
        {
            ipsum[0] = 65 + rand() % 26;
        }
        else
        {
            ipsum[0] = 97 + rand() % 26;
        }
        for (int j = 1; j < 3; ++j)
        {
            random_type = rand() % 3;
            if (random_type == 0)
            {
                ipsum[j] = 65 + rand() % 26;
            }
            else if (random_type == 1)
            {
                ipsum[j] = 97 + rand() % 26;
            }
            else
            {
                ipsum[j] = 48 + rand() % 10;
            }
        }
        ipsum[3] = '\0';

        // temporary version
        rr[(int)i].key = key; // 참고로 rr 은 전역변수로 사용되는중.
        strncpy(rr[(int)i].value, ipsum, 3);
        rr[(int)i].value[3] = '\0';

        // db_insert(key, ipsum); // TODO 주석해제하자. '//' 를 지우기
    }
}

/**
 * Special Area start 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */



// hash function     function name: hash_
uint64_t hash_(int64_t key, size_t table_size)
{
    // Bit mixing and randomization techniques
    key = ~key + (key << 21);
    key = key ^ (key >> 24);
    key = (key + (key << 3)) + (key << 8);
    key = key ^ (key >> 14);
    return key % table_size;
}

// new version with partitioning concept.  function name: hash
uint64_t hash(int64_t key, int num_partitions)
{
    // Use bit manipulation for better distribution
    key = (~key) + (key << 21);
    key = key ^ (key >> 24);
    key = (key + (key << 3)) + (key << 8);
    key = key ^ (key >> 14);

    return abs(key % num_partitions);
}

// Safe memory allocation wrapper
void *MemAlloc(size_t size)
{
    void *ptr = malloc(size);
    if (!ptr)
    {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    return ptr;
}

// Create hash table with dynamic sizing
HashTable *create_hash_table(size_t initial_size)
{
    HashTable *ht = (HashTable *)MemAlloc(sizeof(HashTable));
    ht->size = initial_size;
    ht->count = 0;
    ht->buckets = (HashEntry **)calloc(initial_size, sizeof(HashEntry *));

    if (!ht->buckets)
    {
        free(ht);
        fprintf(stderr, "Hash table bucket allocation failed\n");
        exit(EXIT_FAILURE);
    }

    return ht;
}

// Intelligent insert with collision resolution
void hash_table_insert(HashTable *ht, int64_t key, const char *value)
{
    // Check if we need to resize
    if (ht->count >= ht->size * 0.75)
    {
        fprintf(stderr, "Warning: Hash table load factor exceeded. Consider resizing.\n");
    }

    uint64_t index = hash(key, ht->size);

    // Create new entry
    HashEntry *new_entry = (HashEntry *)MemAlloc(sizeof(HashEntry));
    new_entry->key = key;
    strncpy(new_entry->value, value, MAX_VALUE_LENGTH - 1);
    new_entry->value[MAX_VALUE_LENGTH - 1] = '\0';

    // Chaining: add to the front of the list
    new_entry->next = ht->buckets[index];
    ht->buckets[index] = new_entry;

    ht->count++;
}

// Efficient search with early termination
HashEntry *hash_table_search(HashTable *ht, int64_t key)
{
    uint64_t index = hash(key, ht->size);
    HashEntry *current = ht->buckets[index];

    while (current)
    {
        if (current->key == key)
        {
            return current;
        }
        current = current->next;
    }

    return NULL;
}
/*
// Initialize Partition Context
PartitionContext* create_partition_context(int num_partitions, int initial_capacity) {
    PartitionContext* context = (PartitionContext*)safe_allocate(sizeof(PartitionContext));

    context->partitions = (Partition*)safe_allocate(sizeof(Partition) * num_partitions);
    context->num_partitions = num_partitions;
    context->total_records = 0;

    for (int i = 0; i < num_partitions; i++) {
        context->partitions[i].keys = (int64_t*)safe_allocate(sizeof(int64_t) * initial_capacity);
        context->partitions[i].values = (char**)safe_allocate(sizeof(char*) * initial_capacity);
        context->partitions[i].size = 0;
        context->partitions[i].capacity = initial_capacity;
    }

    return context;
}

// Dynamic Multi-Phase Partitioning
void multi_phase_partition(
    int64_t* input_keys,
    char** input_values,
    int input_size,
    PartitionContext* context
) {
    for (int i = 0; i < input_size; i++) {
        // Determine partition using advanced hash function
        uint32_t partition_index = hash(input_keys[i], context->num_partitions);

        Partition* current_partition = &context->partitions[partition_index];

        // Resize partition if needed
        if (current_partition->size >= current_partition->capacity) {
            int new_capacity = current_partition->capacity * 2;
            current_partition->keys = realloc(current_partition->keys, sizeof(int64_t) * new_capacity);
            current_partition->values = realloc(current_partition->values, sizeof(char*) * new_capacity);
            current_partition->capacity = new_capacity;
        }

        // Add record to partition
        current_partition->keys[current_partition->size] = input_keys[i];
        current_partition->values[current_partition->size] = strdup(input_values[i]);
        current_partition->size++;

        context->total_records++;
    }
}

// Recursive Partitioning Strategy
PartitionContext* recursive_partitioning(
    int64_t* keys,
    char** values,
    int size,
    int max_depth
) {
    // Start with initial partitioning
    PartitionContext* context = create_partition_context(
        fmin(MAX_PARTITIONS, size / 1000 + 1),  // Dynamic partition count
        1000  // Initial partition capacity
    );

    multi_phase_partition(keys, values, size, context);

    // Optional: recursive refinement possibility
    // repartition in some case of large partitions
    if (max_depth > 0) {
        for (int i = 0; i < context->num_partitions; i++) {
            Partition* partition = &context->partitions[i];

            // Repartition large partitions
            if (partition->size > 5000) {
                PartitionContext* sub_context = recursive_partitioning(
                    partition->keys,
                    partition->values,
                    partition->size,
                    max_depth - 1
                );


                free(sub_context);
            }
        }
    }

    return context;
}*/

// without partition concept. just simply, by following the abstract logic.
void hash_join(record *r, int size_r,
               record *s, int size_s,
               int64_t *output_keys_r, int64_t *output_keys_s)
{
    int output_count = 0;

    // Step 1
    HashTable *ht_s = create_hash_table(size_s * 2);
    for (int i = 0; i < size_s; i++)
    {
        hash_table_insert(ht_s, s[i]->key, s[i]->value);
    }

    // Step 2
    for (int i = 0; i < size_r; i++)
    {
        HashEntry *matching_entry = hash_table_search(ht_s, r[i]->key); // ht_s에서 키 검색

        if (matching_entry)
        { // 일치하는 항목이 있으면 결과에 추가
            output_keys_r[output_count] = r[i]->key;
            output_keys_s[output_count] = matching_entry->key;
            output_count++;
        }
    }

    // Cleanup hash tables
    for (size_t i = 0; i < ht_s->size; i++)
    {
        HashEntry *current = ht_s->buckets[i];
        while (current)
        {
            HashEntry *temp = current;
            current = current->next;
            free(temp);
        }
    }
    free(ht_s->buckets);
    free(ht_s);
}
/* 테스트중 아직 주석 해제 못함
// optimized (multi phase depending on the data size and partitioning technique)
int multi_phase_hash_join(record* r, int size_r,
               record* s, int size_s,
               int64_t* output_keys_r, int64_t* output_keys_s) {
    // Partition first relation (R)
    PartitionContext* partitions_r = recursive_partitioning(keys_r, values_r, size_r, 2);

    int match_count = 0;

    // Hash table for S relation
    HashTable* ht_s = create_hash_table(DEFAULT_HASH_TABLE_SIZE);

    // Insert all S keys into hash table
    for (int i = 0; i < size_s; i++) {
        hash_table_insert(ht_s, keys_s[i], &values_s[i]);
    }

    // Join process: Check each partition in R and see if it matches with S's hash table
    for (int p = 0; p < partitions_r->num_partitions; p++) {
        Partition* partition = &partitions_r->partitions[p];

        // Create hash table for current partition
        // (Simplified hash table implementation)

        for (int i = 0; i < partition->size; i++)
        {
            HashEntry* entry = search_in_hash_table(ht_s, partition->keys[i]);
            if (entry != NULL) {
                output_keys_r[match_count] = partition->keys[i];
                output_keys_s[match_count] = entry->key;
                match_count++;
            }
        }
    }

    // Cleanup
    for (int i = 0; i < partitions_r->num_partitions; i++) {
        free(partitions_r->partitions[i].keys);
        for (int j = 0; j < partitions_r->partitions[i].size; j++) {
            free(partitions_r->partitions[i].values[j]);
        }
        free(partitions_r->partitions[i].values);
    }
    free(partitions_r->partitions);
    free(partitions_r);

    free(ht_s);

    return match_count;
}*/

/**
 * Special Area END 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */