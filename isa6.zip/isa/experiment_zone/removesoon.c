#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <assert.h>

// Configurable parameters
#define DEFAULT_HASH_TABLE_SIZE 16384 // Large prime number for better distribution
#define MAX_RECORDS 1000000           // Maximum number of records to handle
#define MAX_VALUE_LENGTH 120          // Maximum length of record value
#define MAX_PARTITIONS 16
#define N_WAY_PASS 3 // just? considering..

// Advanced hash entry with more efficient structure
typedef struct HashEntry
{
    int64_t key;
    char value[MAX_VALUE_LENGTH];
    struct HashEntry *next;
} HashEntry;

// Improved hash table structure
typedef struct
{
    HashEntry **buckets;
    size_t size;
    size_t count; // capacity
} HashTable;
/**
 *
 * buckets: An array of pointers to linked lists (HashEntry).
 * size: The number of buckets in the hash table.
 * count(capacity): The maximum number of entries it can hold before resizing.
 */

// Partition Structure
typedef struct
{
    int64_t *keys;
    char **values;
    int size;
    int capacity;
} Partition;

// Multi-Phase Partitioning Context
typedef struct
{
    Partition *partitions;
    int num_partitions;
    size_t total_records;
} PartitionContext;

// hash function     function name: hash_
uint64_t hash_(int64_t key, size_t table_size)
{
    // Bit mixing and randomization techniques
    key = ~key + (key << 21);
    key = key ^ (key >> 24);
    key = (key + (key << 3)) + (key << 8);
    key = key ^ (key >> 14);
    return key % table_size;
}

// new version with partitioning concept.  function name: hash
uint64_t hash(int64_t key, int num_partitions)
{
    // Use bit manipulation for better distribution
    key = (~key) + (key << 21);
    key = key ^ (key >> 24);
    key = (key + (key << 3)) + (key << 8);
    key = key ^ (key >> 14);

    return abs(key % num_partitions);
}

// Safe memory allocation wrapper
void *MemAlloc(size_t size)
{
    void *ptr = malloc(size);
    if (!ptr)
    {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    return ptr;
}

// Create hash table with dynamic sizing
HashTable *create_hash_table(size_t initial_size)
{
    HashTable *ht = (HashTable *)MemAlloc(sizeof(HashTable));
    ht->size = initial_size;
    ht->count = 0;
    ht->buckets = (HashEntry **)calloc(initial_size, sizeof(HashEntry *));

    if (!ht->buckets)
    {
        free(ht);
        fprintf(stderr, "Hash table bucket allocation failed\n");
        exit(EXIT_FAILURE);
    }

    return ht;
}

// Intelligent insert with collision resolution
void hash_table_insert(HashTable *ht, int64_t key, const char *value)
{
    // Check if we need to resize
    if (ht->count >= ht->size * 0.75)
    {
        fprintf(stderr, "Warning: Hash table load factor exceeded. Consider resizing.\n");
    }

    uint64_t index = hash(key, ht->size);

    // Create new entry
    HashEntry *new_entry = (HashEntry *)MemAlloc(sizeof(HashEntry));
    new_entry->key = key;
    strncpy(new_entry->value, value, MAX_VALUE_LENGTH - 1);
    new_entry->value[MAX_VALUE_LENGTH - 1] = '\0';

    // Chaining: add to the front of the list
    new_entry->next = ht->buckets[index];
    ht->buckets[index] = new_entry;

    ht->count++;
}

// Efficient search with early termination
HashEntry *hash_table_search(HashTable *ht, int64_t key)
{
    uint64_t index = hash(key, ht->size);
    HashEntry *current = ht->buckets[index];

    while (current)
    {
        if (current->key == key)
        {
            return current;
        }
        current = current->next;
    }

    return NULL;
}
/*
// Initialize Partition Context
PartitionContext* create_partition_context(int num_partitions, int initial_capacity) {
    PartitionContext* context = (PartitionContext*)safe_allocate(sizeof(PartitionContext));

    context->partitions = (Partition*)safe_allocate(sizeof(Partition) * num_partitions);
    context->num_partitions = num_partitions;
    context->total_records = 0;

    for (int i = 0; i < num_partitions; i++) {
        context->partitions[i].keys = (int64_t*)safe_allocate(sizeof(int64_t) * initial_capacity);
        context->partitions[i].values = (char**)safe_allocate(sizeof(char*) * initial_capacity);
        context->partitions[i].size = 0;
        context->partitions[i].capacity = initial_capacity;
    }

    return context;
}

// Dynamic Multi-Phase Partitioning
void multi_phase_partition(
    int64_t* input_keys,
    char** input_values,
    int input_size,
    PartitionContext* context
) {
    for (int i = 0; i < input_size; i++) {
        // Determine partition using advanced hash function
        uint32_t partition_index = hash(input_keys[i], context->num_partitions);

        Partition* current_partition = &context->partitions[partition_index];

        // Resize partition if needed
        if (current_partition->size >= current_partition->capacity) {
            int new_capacity = current_partition->capacity * 2;
            current_partition->keys = realloc(current_partition->keys, sizeof(int64_t) * new_capacity);
            current_partition->values = realloc(current_partition->values, sizeof(char*) * new_capacity);
            current_partition->capacity = new_capacity;
        }

        // Add record to partition
        current_partition->keys[current_partition->size] = input_keys[i];
        current_partition->values[current_partition->size] = strdup(input_values[i]);
        current_partition->size++;

        context->total_records++;
    }
}

// Recursive Partitioning Strategy
PartitionContext* recursive_partitioning(
    int64_t* keys,
    char** values,
    int size,
    int max_depth
) {
    // Start with initial partitioning
    PartitionContext* context = create_partition_context(
        fmin(MAX_PARTITIONS, size / 1000 + 1),  // Dynamic partition count
        1000  // Initial partition capacity
    );

    multi_phase_partition(keys, values, size, context);

    // Optional: recursive refinement possibility
    // repartition in some case of large partitions
    if (max_depth > 0) {
        for (int i = 0; i < context->num_partitions; i++) {
            Partition* partition = &context->partitions[i];

            // Repartition large partitions
            if (partition->size > 5000) {
                PartitionContext* sub_context = recursive_partitioning(
                    partition->keys,
                    partition->values,
                    partition->size,
                    max_depth - 1
                );


                free(sub_context);
            }
        }
    }

    return context;
}*/

// without partition concept. just simply, by following the abstract logic.
void hash_join(record *r, int size_r,
               record *s, int size_s,
               int64_t *output_keys_r, int64_t *output_keys_s)
{
    int output_count = 0;

    // Step 1
    HashTable *ht_s = create_hash_table(size_s * 2);
    for (int i = 0; i < size_s; i++)
    {
        hash_table_insert(ht_s, s[i]->key, s[i]->value);
    }

    // Step 2
    for (int i = 0; i < size_r; i++)
    {
        HashEntry *matching_entry = hash_table_search(ht_s, r[i]->key); // ht_s에서 키 검색

        if (matching_entry)
        { // 일치하는 항목이 있으면 결과에 추가
            output_keys_r[output_count] = r[i]->key;
            output_keys_s[output_count] = matching_entry->key;
            output_count++;
        }
    }

    // Cleanup hash tables
    for (size_t i = 0; i < ht_s->size; i++)
    {
        HashEntry *current = ht_s->buckets[i];
        while (current)
        {
            HashEntry *temp = current;
            current = current->next;
            free(temp);
        }
    }
    free(ht_s->buckets);
    free(ht_s);
}
/* 테스트중 아직 주석 해제 못함
// optimized (multi phase depending on the data size and partitioning technique)
int multi_phase_hash_join(record* r, int size_r,
               record* s, int size_s,
               int64_t* output_keys_r, int64_t* output_keys_s) {
    // Partition first relation (R)
    PartitionContext* partitions_r = recursive_partitioning(keys_r, values_r, size_r, 2);

    int match_count = 0;

    // Hash table for S relation
    HashTable* ht_s = create_hash_table(DEFAULT_HASH_TABLE_SIZE);

    // Insert all S keys into hash table
    for (int i = 0; i < size_s; i++) {
        hash_table_insert(ht_s, keys_s[i], &values_s[i]);
    }

    // Join process: Check each partition in R and see if it matches with S's hash table
    for (int p = 0; p < partitions_r->num_partitions; p++) {
        Partition* partition = &partitions_r->partitions[p];

        // Create hash table for current partition
        // (Simplified hash table implementation)

        for (int i = 0; i < partition->size; i++)
        {
            HashEntry* entry = search_in_hash_table(ht_s, partition->keys[i]);
            if (entry != NULL) {
                output_keys_r[match_count] = partition->keys[i];
                output_keys_s[match_count] = entry->key;
                match_count++;
            }
        }
    }

    // Cleanup
    for (int i = 0; i < partitions_r->num_partitions; i++) {
        free(partitions_r->partitions[i].keys);
        for (int j = 0; j < partitions_r->partitions[i].size; j++) {
            free(partitions_r->partitions[i].values[j]);
        }
        free(partitions_r->partitions[i].values);
    }
    free(partitions_r->partitions);
    free(partitions_r);

    free(ht_s);

    return match_count;
}*/

int main()
{
    // int64_t ex_keys_r[] = {1, 2, 3, 4, 5};
    // char* ex_values_r[] = {"Apple", "Banana", "Cherry", "Date", "Elderberry"};
    // int ex_size_r = sizeof(ex_keys_r) / sizeof(ex_keys_r[0]);

    // int64_t ex_keys_s[] = {2, 4, 6, 7, 8};
    // char* ex_values_s[] = {"Banana", "Date", "Fig", "Grape", "Honeydew"};
    // int ex_size_s = sizeof(ex_keys_s) / sizeof(ex_keys_s[0]);

    // Output key array
    int64_t output_keys_r[MAX_RECORDS]; // R
    int64_t output_keys_s[MAX_RECORDS]; // S

    // Perform hash join
    int matches = hash_join(
        rRarray, global_sz_R,
        rSarray, global_sz_S,
        output_keys_r, output_keys_s); // TODO <- test data preparation with actual record struct type

    // Print results
    // printf("Hash Join Results (%d matches):\n", matches);
    for (int i = 0; i < matches; i++)
    {
        printf("Match %d: R Key = %ld, S Key = %ld\n",
               i + 1, output_keys_r[i], output_keys_s[i]);
    }

    /*                                   */

    /* 테스트중, 아직 주석해제 못함
        // Perform multi-phase hash join
        matches = multi_phase_hash_join(
            rRarray, global_sz_R,
            rSarray, global_sz_S,
            output_keys_r, output_keys_s
        );

        // Print results
        printf("\n\n\nMulti-Phase Hash Join Results (%d matches):\n", matches);
        for (int i = 0; i < matches; i++) {
            printf("Match %d: R Key = %ld, S Key = %ld\n",
                   i + 1, output_keys_r[i], output_keys_s[i]);
        }
    */

    return 0;
}