#include "bpt.h"

#define INSERT 'i'
#define FIND 'f'
#define DELETE 'd'
#define QUIT 'q'
#define JOIN 'j'

int main()
{
    int debugRemovesoonFlag = 1;                // Basically default> Not enable // TODO: remove this line
    char debugRemovesoonCharOpt_automode = 'A'; // Basically default> Auto mode  // TODO: remove this line
    int64_t key_input;
    char user_interaction_input;
    char user_value_input[FIX_SIZE];
    char *result_value_string;

    /*****************************/
    /*****************************/



    preprocess_table(tb); /************************************************************************************************************************************************************/  // s=LEFT; (s는 이미 초기 LEFT로 잡혀있음.)
    open_table("left.db"); /************************************************************************************************************************************************************/ /** 조인준비: 왼쪽 테이블을 먼저 open함 **/


    s = RIGHT;
    open_table("right.db");                                                                                                                                                               /** 조인준비: 오른쪽 테이블을 그 다음 open함 **/
    s = LEFT;
    ////////////////////////**************************************************************************************************************************************************************/ // re back to s to LEFT SIDE (<- 이 줄의 목적 및 의의: 삽입/삭제/검색 에 대한 operation 들을, 오직 left table 기준으로만 하려고 함. 그걸 가능하게 하는 코드가 이것.)
    ////////////////////////************************************************************************************************************************************************************/   // 전반적수정사항? 예를 들어 fd를, tb[0].fd  (0으로 하드코딩해도됨 <-  삽입/삭제/검색 부분 / 반면 join 에선 [0], [1] 등 인덱스 여러개 활용(현재todo는이거임.))

    

    if (debugRemovesoonFlag)
    { 
        //printf("Please input the mode(M or A) : ");
        //scanf("%c", &debugRemovesoonCharOpt_automode);
        printf("input mode already: 'M'\n");
        debugRemovesoonCharOpt_automode = 'M';

        // while (getchar() != (int)'\n')
        //     ;
    }

    if (debugRemovesoonCharOpt_automode == 'A')
    {
        // 1. insert   // 2. find   // 3. quit
        // TODO: 시간 재기.  start clock() - end clock  ->  성능  체크.  총 시간: %d ..  

        key_input = 10;
        strcpy(user_value_input, "A");
        db_insert(key_input, user_value_input);
        key_input = 20;
        strcpy(user_value_input, "B");
        db_insert(key_input, user_value_input);
        printf("\nnumInserts : 2\ninsert done: 10 and A\ninsert done: 20 and B\n");

        //

        key_input = 10;
        result_value_string = db_find(key_input);
        if (result_value_string)
        {
            printf("Key: %ld, Value: %s\n", key_input, result_value_string);
            free(result_value_string);
        }
        else
        {
            printf("Not Exists!\n");
        }
        fflush(stdout);

        key_input = 20;
        result_value_string = db_find(key_input);
        if (result_value_string)
        {
            printf("Key: %ld, Value: %s\n", key_input, result_value_string);
            free(result_value_string);
        }
        else
        {
            printf("Not Exists!\n");
        }
        fflush(stdout);

        // quit
        printf("\n\nProgram Finally Terminated.\n");
        return EXIT_SUCCESS;
    }
    else
    {
        /**** M ****/

        while (scanf("%c", &user_interaction_input) != EOF)
        {
            switch (user_interaction_input)
            {
            case INSERT:
                printf("Enter key and value: ");
                scanf("%ld %s", &key_input, user_value_input);
                db_insert(key_input, user_value_input);
                // printf("\ndb_insert_call_done\n");
                break;

            case FIND:
                printf("Enter key: ");
                scanf("%ld", &key_input);
                result_value_string = db_find(key_input);
                if (result_value_string)
                {
                    printf("Key: %ld, Value: %s\n", key_input, result_value_string);
                    free(result_value_string);
                }
                else
                {
                    printf("Not Exists!\n");
                }
                // printf("\ndb_find_call_done\n");
                fflush(stdout);
                break;

            case DELETE:
                printf("Enter key: ");
                scanf("%ld", &key_input);
                db_delete(key_input);
                printf("\ndb_delete_call_done\n");
                break;

            case QUIT:
                while (getchar() != (int)'\n')
                    ;
                printf("\n\n=== Program Finally Terminated. ===\n");
                return EXIT_SUCCESS;
                break;

            case JOIN:
                printf("START   procedure db_join.\n");
                db_join();
                printf("END     procedure db_join.\n");
                break;
            }
            while (getchar() != (int)'\n')
                ;
        }
    }

    printf("\n");
    return 0;
}

// important -> do not remove below line
/**
 *
 * table#1 에 {1,“a”}, {2,“b”}, {3,“c”} 가 저장되어 있고
 * table#2 에 {2,“1”}, {3,“2”}, {4,“3”} 이 저장되어 있다면
 * <2>, b, 1    줄바꿈
 * <3>, c, 2
 * 출력
 */
